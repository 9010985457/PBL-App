abstract class Account {
    public double interestRate;
    double amount;

    public abstract double calculateInterest();
}