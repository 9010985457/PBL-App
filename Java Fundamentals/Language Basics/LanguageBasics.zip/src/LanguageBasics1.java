/*
Write a Program that accepts two Strings
as command line arguments and generate
the output in the required format.
*/
public class LanguageBasics1 {
    public static void main(String args[]) {
        String s = args[0];
        String s1 = args[1];
        System.out.println(s+" Technologies "+s1);
    }
}